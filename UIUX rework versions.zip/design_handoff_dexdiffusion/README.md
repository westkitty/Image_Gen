# Handoff: DexDiffusion UI/UX Rework — Three Versions

## Overview

This design handoff contains three distinct UI/UX reworks of DexDiffusion, a local image generation console interface. Each version explores a different information architecture and visual direction:

- **V1 · Console** — Dark navy sidebar nav with 3-panel layout (sidebar, main canvas, forms)
- **V2 · Studio** — Tab-based top navigation with right-aligned controls
- **V3 · Focus** — Minimalist icon rail navigation with centered canvas

Each version is fully interactive and demonstrates the intended look, feel, navigation flow, and component behaviors.

## About the Design Files

The files in this bundle are **high-fidelity HTML prototypes created as design references**. They are NOT production code to copy directly. Your task is to **recreate these HTML designs in your target codebase** (React, Vue, native app, etc.) using the existing patterns, libraries, and design systems in your project — or, if no environment exists yet, choose the most appropriate framework for your team and implement the designs there.

The prototypes demonstrate:
- Layout and information architecture
- Visual hierarchy and color system
- Component styling (buttons, inputs, selects, details/summary panels)
- Navigation patterns and state management
- Responsive behavior (fullscreen desktop app)
- Typography and spacing scales

## Fidelity

**High-fidelity (hifi)**: Pixel-perfect mockups with final colors, typography, spacing, and interactions fully realized. Recreate the UI **exactly** using your codebase's components and patterns, not by copying the HTML markup directly.

## Screens / Views

All three versions share the same **7 screens**, accessible via sidebar nav (V1), top tabs (V2), or icon rail (V3):

### 1. Create
**Purpose**: Main image generation interface. Users set prompts, parameters, and submit generation jobs.

**Layout**: 
- V1: 2-panel (left: sticky form controls; right: canvas + image display)
- V2: Inverted (left: canvas; right: form controls, scrollable)
- V3: Single-panel canvas with collapsible sidebar

**Components**:
- Generate button (large, high contrast — cyan/green in V1, amber in V2, violet in V3)
- Prompt textarea (5 rows)
- Negative prompt textarea (2 rows)
- Parameter controls: Steps, CFG, Seed (3-column grid)
- Model selects: Target, Preset (2-column grid)
- Advanced dropdowns (collapsible): Sampler, Scheduler, VAE, LoRA, Hires/faces/tiling options
- Dimension inputs + preset buttons (512×512, 768×512, 1024×1024)
- Canvas: centered, with dashed bounding box overlay showing dimensions in monospace font
- Bottom action bar: status text, Copy params, Reuse seed, img2img buttons

**States**:
- Idle: placeholder image, no job running
- Generating: overlay spinner/progress
- Complete: result image displayed in canvas
- Busy: Generate button disabled, opacity reduced

### 2. Library
**Purpose**: Browse and load previous generation runs.

**Layout**: Grid of cards (220px min-width, 3–4 columns on desktop)

**Components**:
- Filter buttons (All, Controlled, SD1.5, SDXL base, SDXL Turbo, Flux fp8, Hires Fix, Upscale, Smoke proofs)
- Compare controls (disabled when no selection; "Latest sweep" button)
- Card layout: thumbnail (4:3 aspect, colored background per model), metadata (run ID, model, size), badge (model type, color-coded)
- Load More button + count display (e.g., "8 of 68 runs")

**Interaction**: Click card to load; drag to compare; filter to narrow results

### 3. Batch / Sweep
**Purpose**: Submit multiple generation jobs with parameter sweeps.

**Layout**: 2-column (left: form; right: preview/results grid)

**Components**:
- Prompt textarea
- Negative prompt textarea
- Sweep axis select (Seed, CFG scale, Steps)
- Parameter ranges (min/max inputs or sliders)
- Batch count input
- Submit button
- Results preview: grid of generated images, each with badge

### 4. Edit (img2img)
**Purpose**: Image-to-image generation from existing outputs.

**Layout**: 2-column similar to Create

**Components**:
- Source run select
- Source image select
- Denoising strength input (0.01–0.99, step 0.05)
- Prompt textarea (editable)
- Negative prompt
- Same parameters as Create
- Canvas showing selected source image

### 5. Enhance
**Purpose**: Upscaling and restoration.

**Layout**: Form + preview

**Components**:
- Source run select
- Source image select
- Scale select (2×, 3×, 4×)
- Resample select (Lanczos, Bicubic, Bilinear)
- Restore faces checkbox
- Real-ESRGAN options (disabled in this version)
- Status text

### 6. Models
**Purpose**: Manage available checkpoints, VAEs, LoRAs.

**Layout**: Scrollable list with action buttons

**Components**:
- Model list: name, size, status indicator
- Action buttons: Check stage, SDXL smoke, Flux smoke, Inventory, Load models, Discover
- Import/export options (collapsed)

### 7. System
**Purpose**: Backend configuration and system settings.

**Layout**: Stacked cards

**Components**:
- Backend URL input + Verify button
- Backend status indicator (colored dot + text)
- Server control buttons: Verify backend, Server status, Start server, Stop server
- Capability gates: checkmarks/circles showing enabled/disabled features
- Privacy toggle: Save prompts in run records (checkbox)
- Recent runs log display

## Interactions & Behavior

### Navigation
- **V1**: Left sidebar; active item has blue background + left border
- **V2**: Top tab bar; active tab has amber bottom border
- **V3**: Left icon rail; active icon has violet highlight + background bar

### Form Fields
- Inputs & textareas: dark backgrounds (#141418 V1, #110a1e V2), light text, thin borders
- Selects: dropdown with options from list
- Details/summary: collapsible sections (Hires, Extra networks, Advanced in V1/V2)
- Checkboxes: native styled with accent color (cyan in V1, amber in V2, violet in V3)

### Button States
- Idle: normal appearance
- Hover: slightly lighter background
- Active/Pressed: accent color + higher contrast
- Disabled: reduced opacity, no cursor interaction

### Canvas Display
- Background: solid dark color (V1: #080c12, V2: #0c0b14, V3: similar)
- Overlay grid: dashed line + crosshairs, centered, faint (opacity 0.05–0.15)
- Dimension label: top-left of box, monospace font, faint color
- Image: centered, max-fit to container, with padding

### Status Chips
- Backend: green dot + label "Online" or "Offline"
- Job status: colored dot (amber for Idle, green for Running, red for Error)
- No job: neutral text "No job"

## State Management

**Global state variables needed**:
- `version` (1, 2, or 3) — controls layout & colors
- `activeNav` (string: "create", "batch", "library", "edit", "enhance", "models", "system")
- `prompt` (string)
- `negPrompt` (string)
- `steps` (number, 1–150)
- `cfg` (number, 1–30)
- `seed` (number or "-1" for random)
- `width` (number, multiple of 8)
- `height` (number, multiple of 8)
- `sampler` (string, select option)
- `scheduler` (string, select option)
- `target` (string, model name)
- `preset` (string, preset name)
- `jobStatus` ("idle", "running", "complete", "error")
- `jobImage` (image data or URL, or null)
- `backendUrl` (string, default "http://localhost:7860")
- `backendStatus` ("online", "offline", "unknown")
- `savePrompts` (boolean, default true)

**State transitions**:
- User fills prompt → enables Generate button
- User clicks Generate → sets jobStatus to "running", shows spinner
- Backend returns result → sets jobStatus to "complete", displays jobImage
- User navigates to different screen → preserves form state in Create
- User clicks Reuse seed → copies last successful seed to seed field

## Design Tokens

### Colors

**V1 · Console (Cyan/Slate theme)**
- Primary accent: `#38bdf8` (cyan-500)
- Secondary: `#65d66e` (green-500)
- Background (dark): `#080c12` (slate-950+)
- Sidebar: `#060a10` (slate-950++)
- Surface: `#141418` (slate-900)
- Text primary: `#e8f0f7` (slate-50)
- Text secondary: `#92a4b8` (slate-400)
- Muted: `#6090a8` (slate-600)
- Border: `rgba(148,163,184,.12)` (slate-400, 12% opacity)

**V2 · Studio (Amber/Purple theme)**
- Primary accent: `#f59e0b` (amber-500)
- Background: `#100f18` (purple-950+)
- Header: `#160f22` (purple-950++)
- Surface: `#110a1e` (purple-950+)
- Text primary: `#eeeaf8` (purple-50)
- Text secondary: `#8888b0` (purple-400)
- Canvas bg: radial-gradient `#120f1d` to `#09080f`
- Border: `rgba(200,180,255,.1)` (purple-300, 10% opacity)

**V3 · Focus (Violet/Slate theme)**
- Primary accent: `#a78bfa` (violet-400)
- Background: similar to V1 (slate-950+)
- Sidebar: similar to V1
- Text: similar to V1
- Canvas: violet-tinted grid overlay

**Common to all versions**:
- Green (success): `#65d66e` (emerald-500)
- Red (error): `#ef4444` (red-500)
- Amber (warning): `#fbbf24` (amber-400)

### Typography

**Font families**:
- Body & UI: DM Sans (Google Fonts, weights 300–700)
- Monospace: IBM Plex Mono (weights 400, 500) — used for dimension labels, param values, seed
- Headings: DM Sans, 700 weight

**Scale** (all pixels):
- XS label: 9px, 10px (all-caps, letter-spacing 0.06–0.14em)
- SM label: 10px–11px (input labels, section headers)
- Base: 12px (regular copy, inputs, selects)
- MD: 13px (body text, form prompts)
- LG: 15px–16px (section titles)
- XL: 18px (screen titles)

**Line heights**:
- Compact: 1.0 (labels)
- Normal: 1.5 (textarea, prose)
- Relaxed: 1.7 (placeholder text)

### Spacing

- Gap/gutter: 6px, 8px, 10px, 12px, 14px, 16px, 18px
- Padding (inputs): 7px–10px vertical, 8px–12px horizontal
- Padding (sections): 14px–16px
- Margin (sections): 12px–16px

### Borders & Shadows

- Radius (inputs, buttons): 6px–8px
- Radius (cards): 12px
- Radius (pills): 999px
- Border width: 1px (all borders)
- Shadows: subtle, `box-shadow: 0 1px 3px rgba(0,0,0,.2)` or none (flat design)

### Interactive States

- Button hover: opacity 0.85–0.9, slight background shift
- Input focus: border color to accent, outline none
- Scrollbar: 4px width, rounded, faint (opacity 0.15–0.2)

## Assets

All images used in the designs are stored in the `uploads/` folder within this project:
- `grok_image_1775518226929.jpg` — Dexter (app icon, small)
- `grok_image_1775521844329.jpg` — Dexter (sidebar brand, large)
- `grok_image_1775518225931.jpg` — Dexter (smaller variant)
- `grok_image_1775518196500.jpg` — Dexter (placeholder variant)
- `grok_image_1775518359715.jpg` — Dexter (variant)
- `grok_image_1775518716150.jpg` — Dexter (canvas placeholder)
- `grok_image_1775519424917.jpg` — Dexter (variant)

These can be replaced with your own assets or API endpoints in the final implementation.

## Files

This handoff includes:
- **DexDiffusion Combined.dc.html** — All three versions in a single interactive prototype (used for design validation & screenshots)
- **DexDiffusion.dc.html** — V1 + V2 + V3 standalone prototype
- **DexDiffusion v2.dc.html** — Alternative iteration of the combined version
- **Screenshots** — 01-versions.png, 02-versions.png, 03-versions.png (visual reference)
- **Uploads** — All Dexter avatar images used in the UI

## Implementation Notes

1. **Start with V1 (Console)** — It's the most feature-complete and represents the core layout pattern.
2. **Use your framework's router** to navigate between screens (Create, Batch, Library, etc.).
3. **Form state management** — Consider Redux, Zustand, or local React state depending on your stack.
4. **Backend integration** — The designs assume a REST API at `backendUrl` (default `http://localhost:7860`). Implement the calls for:
   - `POST /generate` — submit txt2img job
   - `POST /img2img` — submit img2img job
   - `POST /upscale` — submit upscaling job
   - `GET /runs` — fetch library of past runs
   - `GET /status` — check backend health
5. **Canvas display** — Use CSS Grid or Flexbox to center the image; overlay the grid graphic with absolute positioning.
6. **Responsive design** — These are desktop-only (fullscreen app), but ensure they work at 1920×1080 minimum.
7. **Accessibility** — Add ARIA labels, keyboard navigation (Tab, Enter), and focus states.

---

**Questions?** Refer to the HTML prototypes for exact styling details. Each version is fully self-contained and can be opened in a browser to inspect computed styles, DOM structure, and interactions live.
